<?php

namespace App\Models\Despesas;

use Illuminate\Database\Eloquent\Model;

class PagamentoModel extends Model
{
    protected $table = 'Pagamentos';
    //
}