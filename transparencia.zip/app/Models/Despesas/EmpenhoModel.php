<?php

namespace App\Models\Despesas;

use Illuminate\Database\Eloquent\Model;

class EmpenhoModel extends Model
{
    protected $table = 'Empenhos';
    //
}