<?php

namespace App\Models\Despesas;

use Illuminate\Database\Eloquent\Model;

class LiquidacaoModel extends Model
{
    protected $table = 'Liquidacoes';
    //
}