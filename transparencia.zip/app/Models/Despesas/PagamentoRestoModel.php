<?php

namespace App\Models\Despesas;

use Illuminate\Database\Eloquent\Model;

class PagamentoRestoModel extends Model
{
    protected $table = 'PagamentosRestos';
    //
}