<?php

namespace App\Models\Auxiliares;

use Illuminate\Database\Eloquent\Model;

class AuxiliarDespesaModel extends Model
{
    protected $table = 'AuxiliarDespesas';
    //
}